//
// Created by shiyi on 2017/4/2.
//

#ifndef CDN_DIJKSTRA_H
#define CDN_DIJKSTRA_H

#include "Global.h"
#include <vector>
#include <queue>

struct HeapNode{  //prority_queue 中的优先级
    int u,dist;   //dist: u点到起点的最短路 ,u: 有向边的终点
    HeapNode(int u,int d):u(u),dist(d){}
    bool operator < (const HeapNode& h) const {
        return dist>h.dist;
    }
};

struct Edge{
    int v, cost, cap, next;
    Edge(int v,int cap, int cost)
            :v(v), cap(cap), cost(cost)
    {}
};

struct Dijkstra{ //打包在Dijkstra中

    Edge edge[EDGE_MAXNUM];
    int edge_num;
    int node_num;
    int head[MAX_EDGE_NUM];
    bool vis[NODE_MAXNUM];
    int dist[NODE_MAXNUM];
    int pre_node[NODE_MAXNUM];
    int pre_edge[NODE_MAXNUM];
    int flow[NODE_MAXNUM];
    void init(int n){
        memset(head, -1, sizeof(head));
        edge_num = 0;
        node_num = n;
    }
    void addEdge(int u, int v, int cap, int cost){
        edge[edge_num].v = v;
        edge[edge_num].cap = cap;
        edge[edge_num].cost = cost;
        edge[edge_num].next = head[u];
        head[u] = edge_num++;

        edge[edge_num].v = u;
        edge[edge_num].cap = cap;
        edge[edge_num].cost = cost;
        edge[edge_num].next = head[v];
        head[v] = edge_num++;
    }
    //每次只算没满足的消费节点的最大容量合路径
    void dijkstra(int s)
    {
        std::priority_queue<HeapNode> Q;
        memset(dist, 0x3f, sizeof(dist));
        memset(vis, false, sizeof(vis));
        memset(flow, 0x3f, sizeof(flow));

        dist[s] = 0;
        Q.push(HeapNode(s,0));
        while(!Q.empty())
        {
            int u = Q.top().u;
            Q.pop();
            if(vis[u])
                continue;
            vis[u] = true;
            for(int i = head[u]; i != -1; i=edge[i].next)
            {
                Edge& e = edge[i];
                int v = e.v;
                int cost = e.cost;
                if(edge[i^1].cap > 0 && dist[v] > dist[u]+cost)
                {
                    dist[v] = dist[u]+cost;
                    pre_node[v] = u;
                    pre_edge[v] = i^1;
                    flow[v] = std::min(flow[v], edge[i^1].cap);
                    Q.push(HeapNode(v,dist[v]));
                }
            }
        }
    }

};


#endif //CDN_DIJKSTRA_H
